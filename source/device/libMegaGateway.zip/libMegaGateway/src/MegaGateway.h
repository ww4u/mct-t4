#ifndef _MR_GATEWAY_
#define _MR_GATEWAY_

#include "device.h"
#include "mrqdevice.h"
#include "megarobot.h"
#include "system.h"
#include "storage.h"
#include "errorcode.h"
#include "project.h"
#include "../../appendix.h"

#endif
